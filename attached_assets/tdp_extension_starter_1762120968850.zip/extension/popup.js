async function getDetections() {
  const data = await chrome.storage.local.get(["detections", "events"]);
  return { detections: data.detections || {}, events: data.events || [] };
}

async function setDetections(detections) {
  await chrome.storage.local.set({ detections });
}

function toCSV(rows) {
  if (!rows.length) return "";
  const header = Object.keys(rows[0]);
  const lines = [header.join(",")];
  for (const r of rows) {
    lines.push(header.map(k => JSON.stringify(r[k] ?? "")).join(","));
  }
  return lines.join("\n");
}

function download(filename, content, type="text/plain") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function render({ detections, events }) {
  const today = new Date().toISOString().slice(0,10);
  const count = detections[today] || 0;
  document.getElementById("todayCount").textContent = count;
  const log = document.getElementById("log");
  const lines = events.slice(-200).map(e => `[${e.time}] ${e.url} :: ${e.rule || ""}`);
  log.value = lines.join("\n");
}

document.getElementById("exportJson").onclick = async () => {
  const data = await getDetections();
  download("tdp_detections.json", JSON.stringify(data, null, 2), "application/json");
};

document.getElementById("exportCsv").onclick = async () => {
  const { events } = await getDetections();
  const csv = toCSV(events);
  download("tdp_detections.csv", csv, "text/csv");
};

document.getElementById("clear").onclick = async () => {
  await chrome.storage.local.set({ detections: {}, events: [] });
  render(await getDetections());
};

// Keep events lightweight (content.js doesn't push them; you can wire later if desired)
(async () => {
  render(await getDetections());
})();
