// content.js – runs on every page. Privacy-first local checks.

(function () {
  try {
    console.log("[Radar] Content script active on:", location.href);
    const url = new URL(location.href);

    // Basic risk rules (add more later)
    const rules = [];

    // 1) Phishing phrases
    const phishingPhrases = [
      /verify your account/i,
      /urgent action required/i,
      /your password will expire/i,
      /confirm your identity/i,
      /account suspended/i,
      /update billing information/i
    ];
    const bodyText = document.body?.innerText || "";
    for (const rx of phishingPhrases) {
      if (rx.test(bodyText)) {
        rules.push({ id: "phrase", label: "Suspicious phrase detected", details: String(rx) });
        break;
      }
    }

    // 2) Lookalike domains (simple heuristic)
    const lookalikes = [
      ["paypaI.com", "paypal.com"],
      ["faceb00k.com", "facebook.com"],
      ["g00gle.com", "google.com"],
    ];
    const host = url.hostname;
    for (const [bad, good] of lookalikes) {
      if (host.includes(bad)) {
        rules.push({ id: "domain", label: "Lookalike domain", details: `${host} → did you mean ${good}?` });
      }
    }

    // 3) Password fields on insecure origins
    const hasPasswordField = !!document.querySelector('input[type="password"]');
    if (hasPasswordField && url.protocol !== "https:") {
      rules.push({ id: "insecure-form", label: "Password field on non-HTTPS page", details: location.href });
    }

    if (rules.length) {
      // Notify background to bump badge counter
      chrome.runtime.sendMessage({ type: "RADAR_DETECTION", url: location.href, rules })
        .catch(() => {});

      // Render a small dismissible ribbon
      injectRibbon(rules);
    } else {
      // optional ping for debugging
      chrome.runtime.sendMessage({ type: "RADAR_LOG", url: location.href }).catch(() => {});
    }

    function injectRibbon(rules) {
      if (document.getElementById("tdp-radar-ribbon")) return;
      const bar = document.createElement("div");
      bar.id = "tdp-radar-ribbon";
      bar.setAttribute("role", "status");
      bar.style.position = "fixed";
      bar.style.top = "0";
      bar.style.left = "0";
      bar.style.right = "0";
      bar.style.zIndex = "2147483647";
      bar.style.display = "flex";
      bar.style.alignItems = "center";
      bar.style.justifyContent = "space-between";
      bar.style.gap = "12px";
      bar.style.padding = "10px 14px";
      bar.style.background = "rgba(234, 88, 12, 0.98)"; // orange
      bar.style.color = "#fff";
      bar.style.font = "14px/1.35 system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";
      bar.style.boxShadow = "0 2px 6px rgba(0,0,0,0.25)";

      const msg = document.createElement("div");
      msg.textContent = `Scam Radar: ${rules[0].label}` + (rules.length > 1 ? ` (+${rules.length-1} more)` : "");
      bar.appendChild(msg);

      const btns = document.createElement("div");
      btns.style.display = "flex";
      btns.style.gap = "8px";

      const details = document.createElement("button");
      details.textContent = "Details";
      details.style.border = "0";
      details.style.background = "rgba(0,0,0,0.25)";
      details.style.color = "#fff";
      details.style.padding = "6px 10px";
      details.style.borderRadius = "8px";
      details.style.cursor = "pointer";
      details.onclick = () => {
        alert(rules.map(r => `• ${r.label}${r.details ? " – " + r.details : ""}`).join("\n"));
      };

      const close = document.createElement("button");
      close.textContent = "Dismiss";
      close.style.border = "0";
      close.style.background = "rgba(0,0,0,0.25)";
      close.style.color = "#fff";
      close.style.padding = "6px 10px";
      close.style.borderRadius = "8px";
      close.style.cursor = "pointer";
      close.onclick = () => bar.remove();

      btns.appendChild(details);
      btns.appendChild(close);
      bar.appendChild(btns);

      document.documentElement.appendChild(bar);
      // Push page down a bit so it doesn't cover clicks
      const spacer = document.createElement("div");
      spacer.id = "tdp-radar-spacer";
      spacer.style.height = "44px";
      spacer.style.pointerEvents = "none";
      document.documentElement.prepend(spacer);
    }
  } catch (e) {
    // Failsafe
  }
})();

// Store a lightweight event row (date, url, first rule) for popup export
try {
  const first = rules[0];
  const event = { time: new Date().toISOString(), url: location.href, rule: first ? first.label : "" };
  chrome.storage.local.get(["events"]).then(({ events }) => {
    const arr = Array.isArray(events) ? events : [];
    arr.push(event);
    chrome.storage.local.set({ events: arr.slice(-2000) }); // cap
  });
} catch {}
