# TruthDetectorPro – Scam Radar (MV3 Starter)

This is a minimal, privacy-first Chrome extension that runs locally and pairs with your existing PWA.

## Features
- Always-on badge ("ON"; increments with detections)
- Content script scans pages for a few basic risks (phrases, lookalike domains, insecure password forms)
- Dismissible in-page ribbon when a risk is detected
- Popup shows today's count and lets you export JSON/CSV
- All data stored in `chrome.storage.local`

## Load in Chrome (Dev)
1. Go to `chrome://extensions`
2. Enable **Developer mode**
3. **Load unpacked** → select this folder
4. Pin the extension icon (puzzle piece → pin)
5. Browse to any site and watch for the ribbon or check the console logs

## Pairing with the PWA
- Add a button in your PWA to open the extension's popup or docs.
- (Optional) Post messages or use a shared API endpoint for deep scans and evidence export.

## Notes
- This is MV3; background runs as a service worker (sleeps/wakes on events)
- No network calls are made by default; everything is local.
