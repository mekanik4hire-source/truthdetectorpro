// background.js (MV3 service worker)

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#0ea5e9" }); // cyan-ish
});

chrome.runtime.onStartup.addListener(() => {
  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#0ea5e9" });
});

// Keep a simple in-memory cache of today's detections count per day (also persisted in storage)
async function incrementDetectionCount() {
  const today = new Date().toISOString().slice(0,10);
  const data = await chrome.storage.local.get(["detections"]);
  const detections = data.detections || {};
  detections[today] = (detections[today] || 0) + 1;
  await chrome.storage.local.set({ detections });
  const n = detections[today];
  chrome.action.setBadgeText({ text: n > 0 ? String(Math.min(n, 99)) : "ON" });
}

// Listen for pings / detection events from content.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "RADAR_DETECTION") {
    incrementDetectionCount();
    sendResponse({ ok: true });
    return true;
  }
  if (msg?.type === "RADAR_LOG") {
    // no-op: just proves the SW wakes up
    sendResponse({ ok: true });
    return true;
  }
});

// Optional: log tab navigations (for debugging proof-of-life)
chrome.webNavigation.onCommitted.addListener((details) => {
  // Avoid chrome:// and chrome-extension:// logs
  if (details.url && details.url.startsWith("http")) {
    console.log("[Radar] Nav committed:", details.url);
  }
});
